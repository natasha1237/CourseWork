﻿namespace Figures.Entity_Data.Figures_Entities
{
    using Figures.Entity_Data._3D_Figures;

    public class Sphere //: IFigure3D
    {
    }
}
