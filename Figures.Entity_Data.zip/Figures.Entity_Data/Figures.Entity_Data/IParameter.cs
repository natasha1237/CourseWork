﻿namespace Figures.Entity_Data
{
    public interface IParameter
    {
        string Name { get; }
        float Size { get; }
    }
}
