﻿namespace Figures.Entity_Data
{
    public interface IEdge : IParameter
    {
    }
}
